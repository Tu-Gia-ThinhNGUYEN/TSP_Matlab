# MAS_Tools
Random utility functions for Multi-Agent simulations
* fcn_FormationPlot - utility to plot multi agent formation control strategies. Plots initial and final formation along with the trajectories.
* Example file will be added.
